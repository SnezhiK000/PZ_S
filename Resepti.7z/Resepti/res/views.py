from django.shortcuts import render, HttpResponse
from django.template.context_processors import request

from .models import Resepts
from django.db.models import Q

def page_one(request):
    resepts = Resepts.objects.all()
    return render(request, 'page.html', { 'resepts': resepts })

search_resept = request.GET.get('search', '')
if search_resept:
    resepts = resepts.filter(
        Q(name__incontains = search_resept) |
        Q(price__incontains = search_resept)
    )

    duration_filter = request.GET.get('duration','')
    if duration_filter:
