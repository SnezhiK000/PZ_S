from django.shortcuts import render, HttpResponse
from django.template.context_processors import request

from .models import Resepts
from django.db.models import Q

def page_one(request):
    search_resept = request.GET.get('search', '')
    kitchen_filter = request.GET.get('kitchen', '')
    time_filter = request.GET.get('time', '')

    resepts = Resepts.objects.all()

    if search_resept: #применение фильтрации
        resepts = resepts.filter(
            Q(name__icontains=search_resept) |
            Q(ingririents__icontains=search_resept)
        )

    if kitchen_filter:
        resepts = resepts.filter(type_kitchen=kitchen_filter)

    if time_filter:
        try:
            time_value = int(time_filter)
            resepts = resepts.filter(time_cooking__lte=time_value)
        except ValueError:
            pass

    kitchens = Resepts.objects.values_list('type_kitchen', flat=True).distinct()

    context = {
        'resepts': resepts,
        'search_resept': search_resept,
        'kitchen_filter': kitchen_filter,
        'time_filter': time_filter,
        'kitchens': kitchens,
    }

    return render(request, 'page.html', context)
