from django.apps import AppConfig


class SchetConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'schet'
