from django.shortcuts import render, HttpResponse

def page(request):
    return render(request,'page.html')