from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from django.utils import timezone

class Genre(models.Model):
    name = models.CharField(unique=True)

    def __str__(self):
        return  self.name

class Movie(models.Model):
    title = models.CharField(max_length = 100)
    year = models.IntegerField()
    description = models.TextField(null=True) #может быть пустым (это кароче и есть опционально)
    genres = models.ManyToManyField(Genre)

    def __str__(self):
        return  self.title

class Reviewer(models.Model):
    name = models.CharField(max_length = 100)
    age = models.IntegerField(null=True)
    city = models.CharField(null=True)

    def __str__(self):
        return  self.name

class Review(models.Model):
    movie = models.ForeignKey(Movie, on_delete = models.CASCADE)
    reviewer = models.ForeignKey(Reviewer, on_delete = models.CASCADE)
    rating = models.IntegerField(validators=[
                MinValueValidator(1),
                MaxValueValidator(10)
            ])
    text = models.TextField()
    published_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return  self.movie