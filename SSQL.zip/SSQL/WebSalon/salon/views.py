from django.shortcuts import render
from django.utils.duration import duration_string

from .models import Service
from django.db.models import Q

def index(request):
    services = Service.objects.all()
    service_search = request.GET.get('search', '')

#поиск, принимает значение
    if service_search:
        services = services.filter(
            Q (name__icontains=service_search) |
            Q (price_icontains= service_search)
        )


#выпадающий список
    duration_filter= request.GET.get('duration', '')

    if duration_filter:
        services = services.filter (duration__lte = int (duration_filter))
    return render(request, 'index.html', {'services': services, 'service_search': service_search, 'duration_filter': duration_filter} )

    #return render(request, "index.html", {'services': services})

# Create your views here.
